let animais = "Cachorro,Gato,Elefante,Leão";
let arrayAnimais = animais.split(",");
console.log(arrayAnimais[1]);
