let texto = "O céu é azul e lindo";
console.log(texto.split(" ", 3));

