let fruta = "Abacaxi";
console.log(fruta.charAt(3));
