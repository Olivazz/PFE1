
let texto = "Eu amo desenvolver aplicações web";
console.log(texto.split(" ").length);
