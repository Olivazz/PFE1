let frase = "Estudando JavaScript todos os dias";
console.log(frase.slice(10));