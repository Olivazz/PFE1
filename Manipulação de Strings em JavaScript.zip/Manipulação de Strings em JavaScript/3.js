let mensagem = "Aprendendo JavaScript";
console.log(mensagem.slice(11));
