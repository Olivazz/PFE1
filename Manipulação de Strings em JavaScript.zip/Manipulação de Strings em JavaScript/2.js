let palavra = "Programação";
console.log(palavra.charAt(0));
console.log(palavra.charAt(palavra.length - 1));
