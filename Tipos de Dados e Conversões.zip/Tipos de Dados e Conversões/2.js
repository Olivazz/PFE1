// Declaração de variáveis null e undefined
let valorNull = null;
let valorUndefined;

// Usando typeof para verificar os tipos
console.log(typeof valorNull);       // "object" (isso é um comportamento histórico do JavaScript)
console.log(typeof valorUndefined);  // "undefined"

// Criando um objeto e um array
let objeto = { nome: "João" };
let array = [1, 2, 3];

// Verificando tipos com typeof
console.log(typeof objeto);  // "object"
console.log(typeof array);   // "object" (arrays são tecnicamente objetos no JavaScript)

// Declarando um BigInt
let bigIntValor = 1234567890123456789012345678901234567890n;
console.log(typeof bigIntValor); // "bigint"
