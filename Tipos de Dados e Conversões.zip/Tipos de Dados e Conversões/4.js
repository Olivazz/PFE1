// Convertendo boolean para número
let booleanParaNumero = Number(true);  // 1
console.log(booleanParaNumero, typeof booleanParaNumero);

// Convertendo null para número
let nullParaNumero = Number(null);  // 0
console.log(nullParaNumero, typeof nullParaNumero);

// Convertendo undefined para número
let undefinedParaNumero = Number(undefined);  // NaN
console.log(undefinedParaNumero, typeof undefinedParaNumero);
