// Listando os tipos primitivos do JavaScript
let tiposPrimitivos = ["string", "number", "boolean", "undefined", "symbol", "null", "bigint"];
console.log(tiposPrimitivos);

// Declarando uma variável para cada tipo primitivo
let stringExemplo = "Texto";
let numeroExemplo = 123;
let booleanoExemplo = false;
let undefinedExemplo;
let simboloExemplo = Symbol("id");
let nullExemplo = null;
let bigIntExemplo = 1234567890123456789012345678901234567890n;

// Exibindo valores
console.log(stringExemplo, numeroExemplo, booleanoExemplo, undefinedExemplo, simboloExemplo, nullExemplo, bigIntExemplo);

// Verificando se uma variável contém um valor do tipo Symbol
console.log(typeof simboloExemplo === "symbol"); // true
