// Declaração das variáveis
let texto = "Olá, mundo!";    // String
let numero = 42;              // Número
let booleano = true;          // Booleano

// Exibindo valores e tipos no console
console.log(texto, typeof texto);
console.log(numero, typeof numero);
console.log(booleano, typeof booleano);

// Conversão de número para string
let numeroString = String(numero);
console.log(numeroString, typeof numeroString);

// Conversão de string numérica para número
let stringNumerica = "123.45";
let numeroConvertido = Number(stringNumerica);
console.log(numeroConvertido, typeof numeroConvertido);