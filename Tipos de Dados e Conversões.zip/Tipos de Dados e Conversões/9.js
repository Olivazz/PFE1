// Convertendo um número para BigInt
let bigIntValorConvertido = BigInt(1000000000000);
console.log(bigIntValorConvertido, typeof bigIntValorConvertido);
