// Criando uma operação com conversão implícita entre número e string
let concatenacao = "A idade é " + 30;  // O número 30 é convertido para string
console.log(concatenacao, typeof concatenacao); // "A idade é 30" (string)
