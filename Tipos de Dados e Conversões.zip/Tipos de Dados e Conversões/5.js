// Expressão com conversão implícita entre número e string
let resultado = 5 + "10";  // A soma se torna uma concatenação de string
console.log(resultado, typeof resultado);

// Usando operador matemático para converter string em número
let soma = "10" - 5;  // A string "10" é convertida para número
console.log(soma, typeof soma);
